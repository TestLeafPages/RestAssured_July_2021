package runner;

import org.junit.runner.RunWith;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.Karate;

@KarateOptions(features = "src/test/java/features/IncidentManagement.feature")
@RunWith(Karate.class)
public class RunKarate {

}
